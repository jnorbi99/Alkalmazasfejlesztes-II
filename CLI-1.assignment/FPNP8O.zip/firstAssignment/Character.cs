﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace firstAssignment
{
    class Character
    {
        public int ID
        {
            get;
            set;
        }

        public string Name
        {
            get;
            set;
        }

        public string Gender
        {
            get;
            set;
        }

        public string Job
        {
            get;
            set;
        }

        public string House
        {
            get;
            set;
        }

        public string Wand
        {
            get;
            set;
        }

        public string Patronus
        {
            get;
            set;
        }

        public string Species
        {
            get;
            set;
        }

        public string BloodStatus
        {
            get;
            set;
        }

        public string HairColour
        {
            get;
            set;
        }

        public string EyeColour
        {
            get;
            set;
        }

        public string Loyality
        {
            get;
            set;
        }

        public string Skills
        {
            get;
            set;
        }

        public string Birth
        {
            get;
            set;
        }

        public string Death
        {
            get;
            set;
        }
    }
}
