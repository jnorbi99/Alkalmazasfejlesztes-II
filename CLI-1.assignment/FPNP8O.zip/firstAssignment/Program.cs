﻿using firstAssignment;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace firstAssignment
{
    class Program
    {

        static void Main(string[] args)
        {
            Tasks.StartTasks(args);
        }
    }
}
